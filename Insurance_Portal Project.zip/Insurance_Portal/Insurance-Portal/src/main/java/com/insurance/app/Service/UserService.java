package com.insurance.app.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.insurance.app.Entity.User;
import com.insurance.app.Repo.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repo;
	
	public User saveUser(User user) {
		return repo.save(user);
	} 
	
	public List<User>getUsers(){
		return repo.findAll();
	}
	
	public User getUser(Integer userId) {
		return repo.findById(userId).get();
	}
	
	
	public void updateUser(User user) {
		repo.save(user);
	}
	
	
	public void deleteUser(Integer userId) {
		repo.deleteById(userId);
	}
	public User login( String emailId,String password) throws Exception{
		User user=repo.findByUserEmailId(emailId);
	//	System.out.println(user.getPassword());
		if(user.getUserEmailId().equals(emailId)&& user.getUserPassword().equals(password)) {
			return user;
		}else {
			throw new Exception("invalid Credentials");
		}
	
	}
}
