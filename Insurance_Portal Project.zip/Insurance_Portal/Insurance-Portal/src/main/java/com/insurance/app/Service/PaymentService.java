package com.insurance.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.app.Entity.Payment;
import com.insurance.app.Repo.PaymentRepository;
import com.insurance.app.Repo.PaymentRepository;

@Service
public class PaymentService {
	@Autowired
	private PaymentRepository payrepo;
	
	public Payment savePayment(Payment payment) {
		return payrepo.save(payment);
	}
	
	public List<Payment>getPayments(){
		return payrepo.findAll();
	}
	
	public Payment getPayment(Integer paymentId) {
		return payrepo.findById(paymentId).get();
	}
	
	
	public void updatePayment(Payment payment) {
		payrepo.save(payment);
	}
	
	
	public void deletePayment(Integer paymentId) {
		payrepo.deleteById(paymentId);
	}

}
