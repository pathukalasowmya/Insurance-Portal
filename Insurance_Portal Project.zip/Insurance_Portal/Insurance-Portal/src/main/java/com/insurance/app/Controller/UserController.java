package com.insurance.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.app.Entity.User;
import com.insurance.app.Service.UserService;

@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	
	@Autowired
	private UserService service;

	@PostMapping("/user")
	public ResponseEntity<?> save(@RequestBody User user) {
		User saveUser = service.saveUser(user);
		return new ResponseEntity<>(saveUser, HttpStatus.OK);
	}

	@GetMapping("/user")
	public ResponseEntity<?> getUsers() {
		List<User> user = service.getUsers();
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@GetMapping("/user/{userId}")
	public ResponseEntity<?> getUser(@PathVariable Integer userId) {
		User user = service.getUser(userId);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@DeleteMapping("/user/{userId}")
	public ResponseEntity<?> delete(@PathVariable Integer userId) {
		service.deleteUser(userId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping("/user")
	public ResponseEntity<?> update(@RequestBody User userId) {
		service.updateUser(userId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	@PostMapping("user/valid")
	public User login(@RequestBody User user)throws Exception{
		return this.service.login(user.getUserEmailId(), user.getUserPassword());
		
	}

}
