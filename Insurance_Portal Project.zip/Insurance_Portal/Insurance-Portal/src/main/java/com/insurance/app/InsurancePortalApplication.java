package com.insurance.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@SpringBootApplication
@ComponentScan("com.insurance.app")
public class InsurancePortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsurancePortalApplication.class, args);
	}

}
