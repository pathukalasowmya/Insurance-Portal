package com.insurance.app.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.app.Entity.Payment;
import com.insurance.app.Service.PaymentService;
@RestController
@CrossOrigin("http://localhost:4200")

@RequestMapping("/api")
public class PaymentController {
	@Autowired
	private PaymentService payservice;

	@PostMapping("/payment")
	public ResponseEntity<?> save(@RequestBody Payment payment) {
		Payment newpayment = payservice.savePayment(payment);
		return new ResponseEntity<>(newpayment, HttpStatus.CREATED);
	}

	@GetMapping("/payment")
	public ResponseEntity<?> getPayments() {
		List<Payment> payment = payservice.getPayments();
		return new ResponseEntity<>(payment, HttpStatus.OK);
	}

	@GetMapping("/payment/{paymentId}")
	public ResponseEntity<?> getPayment(@PathVariable Integer paymentId) {
		Payment payment = payservice.getPayment(paymentId);
		return new ResponseEntity<>(payment, HttpStatus.OK);
	}

	@DeleteMapping("/payment/{paymentId}")
	public ResponseEntity<?> delete(@PathVariable Integer paymentId) {
		payservice.deletePayment(paymentId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping("/payment")
	public ResponseEntity<?> update(@RequestBody Payment paymentId) {
		payservice.updatePayment(paymentId);
		return new ResponseEntity<>(HttpStatus.OK);
	}


}
