package com.insurance.app.Entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name = "paymentdetails")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private Integer paymentId;
	private double price ;
	private Date date;
	
	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name ="claimId") private Claim claim;
	 */
	

}
