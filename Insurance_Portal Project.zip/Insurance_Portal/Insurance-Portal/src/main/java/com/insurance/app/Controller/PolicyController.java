package com.insurance.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.app.Entity.Policy;
import com.insurance.app.Service.PolicyService;
@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping
public class PolicyController {
	@Autowired
	private PolicyService policyserv;

	@PostMapping("/policy")
	public ResponseEntity<?> save(@RequestBody Policy policy) {
		Policy newpolicy = policyserv.savePolicy(policy);
		return new ResponseEntity<>(newpolicy, HttpStatus.CREATED);
	}

	@GetMapping("/policy")
	public ResponseEntity<?> getPolicys() {
		List<Policy> policy = policyserv.getPolicys();
		return new ResponseEntity<>(policy, HttpStatus.OK);
	}

	@GetMapping("/policy/{policyId}")
	public ResponseEntity<?> getPolicy(@PathVariable Integer policyId) {
		Policy policy = policyserv.getPolicy(policyId);
		return new ResponseEntity<>(policy, HttpStatus.OK);
	}

	@DeleteMapping("/policy/{policyId}")
	public ResponseEntity<?> delete(@PathVariable Integer policyId) {
		policyserv.deletePolicy(policyId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping("/policy")
	public ResponseEntity<?> update(@RequestBody Policy policyId) {
		policyserv.updatePolicy(policyId);
		return new ResponseEntity<>(HttpStatus.OK);
	}


}
