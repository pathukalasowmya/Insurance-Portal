package com.insurance.app.Entity;

import java.sql.Date;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "policydetails")
public class Policy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer  id;
    private String fullName;
    private String dob;
    private String gender;
    private String email;
    private String phone;
    private String address;
    private String occupation;
    private double coverageAmount;
    private String policyType;
    
    @CreationTimestamp
	private Date policyRegisteredDate;
	/*
	 * @ManyToMany(mappedBy = "policies",fetch = FetchType.LAZY) private Set<User>
	 * user;
	 */

}
