package com.insurance.app.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.insurance.app.Entity.User;
import java.util.List;


@Repository
public interface UserRepository extends JpaRepository<User,Integer>{

	User findByUserEmailId(String userEmailId);

}
