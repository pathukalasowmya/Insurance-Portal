package com.insurance.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.app.Entity.Claim;
import com.insurance.app.Repo.ClaimRepository;
import com.insurance.app.Repo.ClaimRepository;
@Service
public class ClaimService {
	@Autowired
	private ClaimRepository claimrepo;
	
	public Claim saveClaim(Claim claim) {
		return claimrepo.save(claim);
	}
	
	public List<Claim>getClaims(){
		return claimrepo.findAll();
	}
	
	public Claim getClaim(Integer claimId) {
		return claimrepo.findById(claimId).get();
	}
	
	
	public void updateClaim(Claim claim) {
		claimrepo.save(claim);
	}
	
	
	public void deleteClaim(Integer claimId) {
		claimrepo.deleteById(claimId);
	}

}
