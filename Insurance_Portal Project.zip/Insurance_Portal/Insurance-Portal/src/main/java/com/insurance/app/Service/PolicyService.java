package com.insurance.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.app.Entity.Policy;
import com.insurance.app.Repo.PolicyRepository;
import com.insurance.app.Repo.PolicyRepository;
@Service
public class PolicyService {
	
	@Autowired
	private PolicyRepository policyrepo;
	
	public Policy savePolicy(Policy policy) {
		return policyrepo.save(policy);
	}
	
	public List<Policy>getPolicys(){
		return policyrepo.findAll();
	}
	
	public Policy getPolicy(Integer policyNo) {
		return policyrepo.findById(policyNo).get();
	}
	
	
	public void updatePolicy(Policy policy) {
		policyrepo.save(policy);
	}
	
	
	public void deletePolicy(Integer policyNo) {
		policyrepo.deleteById(policyNo);
	}

}
