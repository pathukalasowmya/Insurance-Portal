package com.insurance.app.Entity;

public class lifeInsurence {

}
