package com.insurance.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.app.Entity.Claim;
import com.insurance.app.Service.ClaimService;
@CrossOrigin("http://localhost:4200")

@RestController
@RequestMapping("/api")
public class ClaimController {
	@Autowired
	private ClaimService claimservice;

	@PostMapping("/claim")
	public ResponseEntity<?> save(@RequestBody Claim claim) {
		Claim newclaim = claimservice.saveClaim(claim);
		return new ResponseEntity<>(newclaim, HttpStatus.CREATED);
	}

	@GetMapping("/claim")
	public ResponseEntity<?> getClaims() {
		List<Claim> claim = claimservice.getClaims();
		return new ResponseEntity<>(claim, HttpStatus.OK);
	}

	@GetMapping("/claim/{claimId}")
	public ResponseEntity<?> getClaim(@PathVariable Integer claimId) {
		Claim claim = claimservice.getClaim(claimId);
		return new ResponseEntity<>(claim, HttpStatus.OK);
	}

	@DeleteMapping("/claim/{claimId}")
	public ResponseEntity<?> delete(@PathVariable Integer claimId) {
		claimservice.deleteClaim(claimId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping("/claim")
	public ResponseEntity<?> update(@RequestBody Claim claimId) {
		claimservice.updateClaim(claimId);
		return new ResponseEntity<>(HttpStatus.OK);
	}


}
