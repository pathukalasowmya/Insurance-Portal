import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { RegisterComponent } from './components/register/register.component';
import { CarinsuranceComponent } from './forms/carinsurance/carinsurance.component';
import { LifeinsuranceComponent } from './forms/lifeinsurance/lifeinsurance.component';
import { HomeinsuranceComponent } from './forms/homeinsurance/homeinsurance.component';
import { LoginComponent } from './components/login/login.component';
import { HealthinsuranceComponent } from './forms/healthinsurance/healthinsurance.component';
import { PolicyComponent } from './components/policy/policy.component';
import { PolicyListComponent } from './components/policy-list/policy-list.component';

const routes: Routes = [
  {path:"",component:HomeComponent,title:'Home Page'},
  {path:"About-Us",component:AboutComponent,title:'AboutUs Page'},
  {path:"Contact-Us",component:ContactComponent,title:'ContactUs Page'},
  {path:"user-reg",component:RegisterComponent,title:'User Register'},
  {path:"user-login",component:LoginComponent, title:'userlogin'},
  {path:"user-policy",component:PolicyComponent,title:'Policy'},
  {path:"show-policy",component:PolicyListComponent,title:"PolicyList"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
