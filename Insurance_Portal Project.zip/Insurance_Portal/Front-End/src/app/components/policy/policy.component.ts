import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PolicyService } from '../../service/policy.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrl: './policy.component.css'
})
export class PolicyComponent {
  PolicyFormGroup: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private policyService: PolicyService,
    private router: Router
  ) {}

  ngOnInit() {
    this.PolicyFormGroup = this.formBuilder.group({
      fullName:['',[Validators.required]],
      dob:['',[Validators.required]],
      gender:['',[Validators.required]],
      email:['',[Validators.required]],
      phone:['',[Validators.required]],
      address:['',[Validators.required]],
      occupation:['',[Validators.required]],
      coverageAmount:['',[Validators.required]],
      policyType:['',[Validators.required]],
  });
  }
  savePolicy(){
    if(this.PolicyFormGroup.valid){
      console.log(this.PolicyFormGroup.value)
      this.policyService
      .savePolicy(this.PolicyFormGroup.value)
      .subscribe((data)=>{
        alert("New Policy is Added ");
        this.router.navigateByUrl('show-policy');
      });
    }else{
      alert("Invalid form")
    }

  }
}
