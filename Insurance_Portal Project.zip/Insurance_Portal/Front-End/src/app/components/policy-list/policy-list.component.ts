import { Component } from '@angular/core';
import { PolicyService } from '../../service/policy.service';
import { Router } from '@angular/router';
import { Policy } from '../../classes/policy';

@Component({
  selector: 'app-policy-list',
  templateUrl: './policy-list.component.html',
  styleUrl: './policy-list.component.css'
})
export class PolicyListComponent {
  policys:Policy[] =[];
  constructor(
    private policyService: PolicyService,
    private router:Router){ } 
  ngOnInit(){
    this.getAllEmployees();
  }
  getAllEmployees(){
    this.policyService.getPolicys().subscribe((data) => {
      this.policys = data;
    });
  }
  removeEmployee(employeeId: number){
    if(confirm('are u sure delete this empployee?')){
      this.policyService.deletePolicy(employeeId).subscribe((data) => {
        alert('employee Successfully deleted!');
        this.getAllEmployees();
      });
    }
  }
  showEdit(id:number){
    this.router.navigate(['edit',id])
  }

}
