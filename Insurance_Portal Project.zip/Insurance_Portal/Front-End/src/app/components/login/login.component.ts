import { Component } from '@angular/core';
import { UserService } from '../../service/user.service';
import { Router } from '@angular/router';
import { User } from '../../classes/user';
import { error } from 'console';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent {
  storage: Storage = localStorage

  constructor(private UserService: UserService, private router: Router) { }

  players: any;
  loginForm = new FormGroup({
    userEmailId: new FormControl('', [Validators.required, Validators.maxLength(30)]),
    userPassword: new FormControl('', [Validators.required, Validators.maxLength(30)]),

  });
  login(insert: any) {
    console.log(this.loginForm);
  }
  get userEmailId() {
    return this.loginForm.get('email');

  }
  get userPassword() {
    return this.loginForm.get('password')
  }
  submit() {
    if (this.userEmailId?.invalid || this.userPassword?.invalid) {
      alert("enter valid details")
    }
    else {
      alert(JSON.stringify(this.loginForm.value))
      let user: User = new User()
      
      user.userEmailId = this.loginForm.value.userEmailId
      user.userPassword = this.loginForm.value.userPassword



      this.UserService.getUser(user).subscribe
        (
          data => {
            console.log(data)
            this.UserService.getUser(user).subscribe()
            this.storage.setItem('currentEmployee', JSON.stringify(this.userEmailId?.value));
            alert("loged in")
            this.router.navigate(['/forms/lifeinsurance'])
          },
          error => {
            alert("invalid credentials")
          }

        )

    }
  }


  submit1() {
    localStorage.setItem('currentUser', JSON.stringify(this.userEmailId?.value ));
    this.router.navigate(['/forgotpassword']);
  }


}
