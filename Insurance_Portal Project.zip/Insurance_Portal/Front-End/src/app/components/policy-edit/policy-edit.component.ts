import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PolicyService } from '../../service/policy.service';
import { Policy } from '../../classes/policy';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-policy-edit',
  templateUrl: './policy-edit.component.html',
  styleUrl: './policy-edit.component.css'
})
export class PolicyEditComponent {
  PolicyFormgroup: FormGroup;
  policy:Policy=new Policy();
  PolicyFormGroup:any;
  activatedRout: any;

  constructor(
    private formBuilder: FormBuilder,
    private policyService: PolicyService,
    private router: Router
  
  ) {}

  ngOnInit() {
    this.PolicyFormGroup = this.formBuilder.group({
      fullName:['',[Validators.required]],
      dob:['',[Validators.required]],
      gender:['',[Validators.required]],
      email:['',[Validators.required]],
      phone:['',[Validators.required]],
      address:['',[Validators.required]],
      occupation:['',[Validators.required]],
      coverageAmount:['',[Validators.required]],
      policyType:['',[Validators.required]],
  });
  let id = this.activatedRout.snapshot.params['id'];

    this.policyService.getPolicy(id).subscribe((data) => {
      this.policy= data;
    });
  }

  editPolicy() {
      if (confirm('Are you sure to update this employeee')) {
        this.policyService.updatePolicy(this.policy).subscribe((data) => {
          alert('Employee Details updated Sucessfully!');
          this.router.navigateByUrl('/employee-list');
        });
    }

  }
}
