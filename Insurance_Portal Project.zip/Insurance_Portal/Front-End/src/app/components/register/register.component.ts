import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  userFormGroup: FormGroup;
 
    constructor(
      private formBuilder:FormBuilder,
      private UserService : UserService,
      private router : Router){}
     ngOnInit(){
      this.userFormGroup=this.formBuilder.group({
        userName:['',[Validators.required,Validators.pattern('[A-Za-z]+')]],
        userEmailId :['',[Validators.required,Validators.email]],
        userPassword:['',[Validators.required,Validators.pattern('[0-9-Za-z]+')]],
      });
     }
     saveUser(){
      if(this.userFormGroup.valid){
        this.UserService
        .saveUser(this.userFormGroup.value)
        .subscribe((data)=>{
          alert('New User Registeration Successful');
          this.router.navigateByUrl('/user-login');
        });
        if(this.userFormGroup.invalid){
          alert('Form is invalid');
        }
      }
     }
  

  // constructor(
  //   private UserService: UserService,
  //   private formBuilder: FormBuilder,
  //   private router: Router
  // ) {}
  // isLoading: boolean = false;
  // LoadingTitle: string = 'Loading';

  // errors: any = [];
  // ngOnInit() {
  //     this.userFormGroup = this.formBuilder.group({
  //       userName:['',[Validators.required,Validators.pattern('[A-Za-z]')]],
  //       userEmailId:['',[Validators.required,Validators.email]],
  //       userPassword:['',[Validators.required,Validators.pattern('[{1-9}A-Za-z]')]]
  //   });
  // }

  // saveUser() {
  //   if (this.userFormGroup.valid) {
  //     this.UserService.saveUser(this.userFormGroup.value).subscribe((data) => {
  //       alert('please check your email');
  //       this.router.navigateByUrl('/login');
  //     });
  //   } else {
  //     alert('Please fill all the fields correctly');
  //   }
  

  // saveUser(){

  //   this.isLoading=true;
  //   this.LoadingTitle='Saving';
  //   var inputData ={
  //     userName:this.userName,
  //     userEmaiId:this.userEmaiId,
  //     userPassword:this.userPassword,
  //   }
  //   this.UserService.saveUser(inputData).subscribe({
  //     next: (res: any)=>{
  //       console.log(res,'response');

  //       this.isLoading=false;

  //       alert(res.message);
  //       this.userName='';
  //       this.userEmaiId='';
  //       this.userPassword='';
  //     },
  //     error: ( err: any)=>{
  //       this.errors = err.error.errors;
  //       this.isLoading=false;
  //       console.log(err.error.errors,'errors')
  //     }

  //   });

  // }

  //   userFormgroup: FormGroup;

  //   constructor(
  //     private formBuilder: FormBuilder,
  //    private service: UserService,
  //   private router: Router
  // ) {}

  //   ngOnInit() {
  //   this.userFormgroup = this.formBuilder.group({
  //       userName: ['', [Validators.required, Validators.pattern('^[a-zA-z]*$')]],
  //        userEmailId: ['', [Validators.required, Validators.email]],
  //        URLSearchParamsPassword: ['', [Validators.required]],
  //      });
  //   }

  //   addUser() {
  //     if (this.userFormgroup.valid) {
  //        this.service.createUser(this.userFormgroup.value).subscribe((data) => {
  //          alert('Please check your Email');
  //          this.router.link(['user/login']);
  //        });
  //      } else {
  //        alert('Please fill all the fields Correctly');
  //      }
  //   }
}
