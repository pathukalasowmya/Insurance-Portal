import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Navbar1Component } from './navbar1/navbar1.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { LifeinsuranceComponent } from './forms/lifeinsurance/lifeinsurance.component';
import { CarinsuranceComponent } from './forms/carinsurance/carinsurance.component';
import { HomeinsuranceComponent } from './forms/homeinsurance/homeinsurance.component';
import { HealthinsuranceComponent } from './forms/healthinsurance/healthinsurance.component';
import { RegisterComponent } from './components/register/register.component';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
//import { LoaderComponent } from './components/loader/loader.component';
import { PolicyComponent } from './components/policy/policy.component';
import { PolicyListComponent } from './components/policy-list/policy-list.component';
import { PolicyEditComponent } from './components/policy-edit/policy-edit.component';

@NgModule({
  declarations: [
    AppComponent,
    Navbar1Component,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    RegisterComponent,
    LoginComponent,
    PolicyComponent,
    PolicyListComponent,
    PolicyEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
