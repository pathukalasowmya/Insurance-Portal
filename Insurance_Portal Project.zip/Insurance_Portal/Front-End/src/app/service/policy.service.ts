import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Policy } from '../classes/policy';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  baseUrl: string = 'http://localhost:8080/myapp/policy';
  
  constructor(private http: HttpClient) {}

  savePolicy(policy: Policy): Observable<Policy> {
    return this.http.post<Policy>(this.baseUrl, policy);
  }
  getPolicys(): Observable<Policy[]> {
    return this.http.get<Policy[]>(this.baseUrl);

  }
  deletePolicy(id: number): Observable<any> {
    return this.http.delete(this.baseUrl + '/' + id);
  }
  getPolicy(data: any): Observable<Policy> {
    return this.http.get<Policy>(this.baseUrl + '/' + data);
  }
  updatePolicy(policy: Policy): Observable<any> {
    return this.http.put(this.baseUrl, policy);
  }
}
