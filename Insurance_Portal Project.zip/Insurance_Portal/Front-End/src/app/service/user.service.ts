import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../classes/user';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  baseUrl: string = 'http://localhost:8080/myapp/user';
  constructor(private http: HttpClient) {}

  saveUser(user: User): Observable<User> {
    return this.http.post<User>(this.baseUrl, user);
  }
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.baseUrl);

  }
  deleteUser(id: number): Observable<any> {
    return this.http.delete(this.baseUrl + '/' + id);
  }
  getUser(data: any): Observable<User> {
    return this.http.get<User>(this.baseUrl + '/' + data);
  }
  updateUser(User: User): Observable<any> {
    return this.http.put(this.baseUrl, User);
  }
  getUserUser(data:User): Observable<any> {
    return this.http.post(this.baseUrl + '/valid', data);
  }
}
