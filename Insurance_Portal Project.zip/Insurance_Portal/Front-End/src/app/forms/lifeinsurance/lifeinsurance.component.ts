import { Component } from '@angular/core';

@Component({
  selector: 'app-lifeinsurance',
  templateUrl: './lifeinsurance.component.html',
  styleUrl: './lifeinsurance.component.css'
})
export class LifeinsuranceComponent {

  id?: number;
  lastName: string;
  firstName: string;
  dob: string;
  gender: string;
  email: string;
  phone: string;
  address: string;
  occupation: string;
  annualIncome: number;
  coverageAmount: number;
  policyType: string;
}



