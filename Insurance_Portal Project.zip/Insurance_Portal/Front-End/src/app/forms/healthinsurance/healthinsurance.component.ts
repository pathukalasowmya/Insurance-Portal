import { Component } from '@angular/core';

@Component({
  selector: 'app-healthinsurance',
  templateUrl: './healthinsurance.component.html',
  styleUrl: './healthinsurance.component.css'
})
export class HealthinsuranceComponent {

}
