import { Component } from '@angular/core';

@Component({
  selector: 'app-carinsurance',
  templateUrl: './carinsurance.component.html',
  styleUrl: './carinsurance.component.css'
})
export class CarinsuranceComponent {

}
