import { Component } from '@angular/core';

@Component({
  selector: 'app-homeinsurance',
  templateUrl: './homeinsurance.component.html',
  styleUrl: './homeinsurance.component.css'
})
export class HomeinsuranceComponent {

}
