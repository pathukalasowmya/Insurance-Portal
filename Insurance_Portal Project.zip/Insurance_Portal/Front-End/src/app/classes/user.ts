export class User {
    userId:number|string|null|undefined
    userName:string
    userEmailId:string|null|undefined
    userPassword:string|null|undefined
    registrationDate:Date
    
}
