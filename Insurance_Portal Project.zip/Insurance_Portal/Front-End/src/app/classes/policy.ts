export class Policy {
    id: number;
    fullName:string
  dob: string;
  gender: string;
  email: string;
  phone: string;
  address: string;
  occupation: string;
  coverageAmount: number;
  policyType: string;
  policyRegisteredDate:Date
}
